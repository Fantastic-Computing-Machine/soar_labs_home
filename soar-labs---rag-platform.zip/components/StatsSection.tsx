import React from 'react';
import { STATS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'Traditional Search', speed: 800 },
  { name: 'Competitor A', speed: 450 },
  { name: 'Soar Labs', speed: 90 },
];

const StatsSection: React.FC = () => {
  return (
    <section className="py-24 bg-white/30 backdrop-blur-3xl border-y border-slate-100/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Text Stats */}
            <div className="grid grid-cols-2 gap-6">
            {STATS.map((stat, index) => (
                <div key={index} className="text-center p-8 bg-white/70 backdrop-blur-sm rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="text-5xl font-display font-bold text-slate-900 mb-2">
                    {stat.value}<span className="text-3xl text-brand-600 ml-1">{stat.suffix}</span>
                </div>
                <div className="text-sm text-slate-500 uppercase tracking-wider font-semibold">{stat.label}</div>
                </div>
            ))}
            </div>

            {/* Chart */}
            <div className="bg-white/80 backdrop-blur-md p-8 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50">
                <div className="mb-8">
                    <h3 className="text-slate-900 font-bold text-xl">Average Latency (Lower is Better)</h3>
                    <p className="text-slate-500 text-sm">Comparing query response times across platforms</p>
                </div>
                <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                            layout="vertical"
                            data={data}
                            margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" width={120} tick={{fill: '#475569', fontSize: 13, fontWeight: 500}} axisLine={false} tickLine={false} />
                            <Tooltip 
                                cursor={{fill: 'transparent'}}
                                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff', padding: '12px' }}
                                itemStyle={{ color: '#fff' }}
                            />
                            <Bar dataKey="speed" barSize={32} radius={[0, 6, 6, 0]}>
                                {data.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.name === 'Soar Labs' ? '#3b82f6' : '#e2e8f0'} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                <div className="mt-6 flex items-center gap-2 text-sm text-slate-400 justify-center bg-slate-50/50 py-2 rounded-lg">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                    Benchmarks based on 1M vector index query.
                </div>
            </div>
        </div>

      </div>
    </section>
  );
};

export default StatsSection;